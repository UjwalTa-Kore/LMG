function isCancelledBookings(data, orderId) {
  if (data.length === 0)
    return false
  for(var i=0;i<data.length;i++)
  {
    if(data[i].orderIdToBeShown === orderId){
      return true
    }
    else {
      return false
    }
  }
}